<?php
include_once "inc/session.php";
include_once "inc/controller.php";
include_once "inc/user_data.php";
include_once "inc/site_controller.php";
$add_user = new controller;
$get_asset_id = ($add_user->get_request('aset'));
$patients_profile = $add_user->edit_patients($hos_key,$get_asset_id);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Patient profile | Referral Letter</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/plugins/summernote/summernote-bs4.css" rel="stylesheet">
    <style>
        body, h1, h2, h3, h4, h5, h6  {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>

<body>

<div id="wrapper">

    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>

        <div class="wrapper wrapper-content">
            <div class="row">
                <div class="col-lg-2">
                    <?php
                    include_once "inc/counter_menu.php";
                    ?>
                </div>
                <div class="col-lg-10 animated fadeInRight">
                    <div class="mail-box-header">
                        <a href="host_patients_folder?aset=<?= base64_encode($get_asset_id); ?>"> <button class="font-weight-bold btn btn-danger btn-outline btn-rounded pull-right">Patient Folder</button></a>

                        <h2 class="font-weight-bold"><img src="doc_icon.png" height="60">  Referral Letter / Folder</h2>
                             <br>
                    </div>


                    <div class="wrapper wrapper-content animated fadeInRight">


                        <div class="row m-b-lg m-t-lg">
                            <div class="col-md-6">

                                <div class="profile-image">
                                    <img src="img/log.png" class="rounded-circle circle-border m-b-md" alt="profile">
                                </div>
                                <div class="profile-info">
                                    <div class="">
                                        <div>
                                            <h2 class="no-margins font-weight-" style="text-transform: capitalize">
                                                <?= $patients_profile->patient_name;  ?>
                                            </h2>
                                            <h4>Referral Letter / New / Manage</h4>
                                            <small>
                                                <a> <button class="btn btn-primary btn-outline btn-rounded font-weight-bold" data-toggle="modal" data-target="#myModal22" >Add Referral  Note</button>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-11 m-b-lg">
                                <div id="vertical-timeline" class="vertical-container light-timeline no-margins">

                                    <?php
                                    $all_appoints = $add_user->referral_letters($get_asset_id);
                                    foreach ($all_appoints as $key=> $ad){
                                    ?>
                                    <div class="vertical-timeline-block">
                                        <div class="vertical-timeline-icon navy-bg">
                                            <i class="fa fa-newspaper-o"></i>
                                        </div>

                                        <div class="vertical-timeline-content">

                                            <h4><?= html_entity_decode($ad->description);  ?>
                                            </h4>

                                            <?php
                                            if($ad->doc_id==$user_id){
                                                echo'<a class="btn btn-sm btn-primary btn-outline btn-rounded font-weight-bold cc" data-id="'.$ad->id.'"> Delete Note</a>';
                                            }
                                            ?>
                                            <span class="vertical-date font-weight-bold text-secondary">
                                        Posted By <?= $ad->fullname;  ?><br>
                                        <small><?= $ad->dated;  ?></small>
                                    </span>
                                        </div>
                                    </div>

                                    <?php
                                    }
                                    ?>
                                </div>

                            </div>

                        </div>

                    </div>




                </div>
            </div>
        </div>
        <input type="hidden" value="<?= $hos_key; ?>" id="host_key">
        <?php
        include_once "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- iCheck -->
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script src="js/plugins/dataTables/datatables.min.js"></script>

<!-- SUMMERNOTE -->
<script src="js/plugins/summernote/summernote-bs4.js"></script>

<!-- Select2 -->
<script src="js/plugins/select2/select2.full.min.js"></script>
<script src="https://cdn.lordicon.com/lusqsztk.js"></script>
<script>
    $(document).ready(function(){

        $('.summernote').summernote();
        // $('.summernote1').summernote();

    });
</script>
<script>

    // Upgrade button class name
    $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

    $(document).ready(function(){
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [

            ]

        });

    });

</script>

<script>
    $(document).ready(function () {


        $(".cc").click(function () {

            // get the para from data-
            const host_fib = $(this).attr("data-id");
            $.ajax({
                url: "ajax/delete_referals_note",
                method: "GET",
                data: {
                    host_fib: host_fib,
                },
                success: function (data) {
                    swal("Good job!", "This Referral Letter Has Been Removed", "success");
                    setTimeout(
                        function () {
                            location.reload();
                        }, 3000);

                    if (data.trim() == 'done') {

                    }
                }
            });
        });


        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
</script>

<script>
    $(document).ready(function () {
        /* function to login user */
        $("#submitForm").on('submit',(function(e) {
            e.preventDefault();
            var btn = $("#reset-btn");
            btn.attr('disabled', true).html("<i class='fa fa-spin fa-spinner'></i> processing");
            var datas = new FormData(this);
            $.ajax({
                url: "ajax/add_referals",
                type: "POST",
                data: datas,
                contentType: false,
                cache: false,
                processData:false,
                success: (data)=> {

                    if(data.trim() == "done"){
                        swal("Good job!", "Referral Letter Created!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);
                    }else{
                    }
                },

            });
        }));

    });
</script>
</body>

</html>

<div class="modal inmodal" id="myModal22" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content animated flipInY">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span
                        class="sr-only">Close</span></button>
                <p class="modal-title font-weight-bold">Add Referral Note</p>
                <!--                <small class="font-bold">You can add and assign Lab to department.</small>-->
            </div>
            <div class="modal-body">
                <form method="POST" id="submitForm">
                <div class="form-group row">

                    <div class="col-sm-12">

                        <div class="form-group"><label class="font-weight-bold">Note Descriptions</label>

                            <textarea class="summernote input-block-level" id="content" name="description" cols="10" rows="18">

...
                                <br>
...
                                   <br>
...
                                   <br>
...
                                   <br>
...
                                   <br>
...
                                   <br>
...

                                                </textarea>

                        </div>

                        <input type="hidden" value="<?= $get_asset_id; ?>" name="pid">

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white btn-rounded" data-dismiss="modal">Close</button>
                <input type="submit"
                       class="font-weight-bold btn btn-primary btn-outline btn-rounded pull-right"
                       value="Add Comment" id="reset-btn">
            </div>
        </div>

    </form>
    </div>
</div>



