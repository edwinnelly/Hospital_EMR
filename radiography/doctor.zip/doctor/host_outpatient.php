<?php
include_once "inc/session.php";
include_once "inc/controller.php";
include_once "inc/user_data.php";
include_once "inc/site_controller.php";
$add_user = new controller;

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital / Outpatient | Controls</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <style>
        body, h1, h2, h3, h4, h5, h6  {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>
<body>
<div id="wrapper">
    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>
        <div class="wrapper wrapper-content">
            <div class="row">
                <div class="col-lg-12 animated fadeInRight">
                    <div class="mail-box-header">
                        <h2>
                            <h3 class="font-weight-bold"> Hospital / Outpatient / My queue <a href="host_doc_specialist.php">
                                    <button class="font-weight-bold btn btn-danger btn-outline btn-rounded pull-right btn-sm">
                                        Specialist Queue
                                    </button>
                                </a><a href="host_outpatient_all.php">
                                    <button class="font-weight-bold btn btn-danger btn-outline btn-rounded pull-right btn-sm">
                                        All Queue
                                    </button>
                                </a><a href="host_outpatient.php">
                                    <button class="font-weight-bold btn btn-danger btn-outline btn-rounded pull-right btn-sm">
                                        My Queue
                                    </button>
                                </a></h3>

                        </h2>
                        <div class="mail-tools tooltip-demo m-t-md">


                            <div class="col-lg-6">
                                <div>
                                    <table class="table">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <button type="button" class="btn btn-danger m-r-sm"><?php echo $add_user->all_count_outpat($hos_key,$user_id); ?></button>
                                                Total Outpatient
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-primary m-r-sm"><?php echo $add_user->all_count_outpat_seen($hos_key,$user_id); ?></button>
                                                Seen
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-info m-r-sm"><?php echo $add_user->all_count_outpat_open($hos_key,$user_id); ?></button>
                                                Pending
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>
                                </div>
                                <div>


                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="mail-box">
                        <div class="ibox-content table-responsive">

                            <table class="table table-hover table-mail dataTables-example">
                                <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Patients Names</th>
                                    <th>Hospital Number</th>
                                    <th>Age</th>
                                    <th>Sex</th>
                                    <th>Specialty</th>
                                    <th>Doctor</th>
                                    <th>Coverage</th>
                                    <th>Folder status</th>
                                    <th>Actions</th>

                                </tr>
                                </thead>
                                <tbody>

                                <?php
                                $i = 0;
                                $lab_list_dpt = $add_user->hospital_patients_q($hos_key,$user_id);
                                foreach ($lab_list_dpt as $key => $values) {
                                    $i++;
                                    ?>
                                    <tr class="gradeA">
                                        <td><?= $i; ?></td>
                                        <td><?= $values->patient_name; ?></td>
                                        <td>HPN<?= $values->id; ?></td>

                                        <td><?php
                                            $birthDate = date('d/m/Y', strtotime($values->age));
                                            //explode the date to get month, day and year
                                            $birthDate = explode("/", $birthDate);
                                            //get age from date or birthdate
                                            $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
                                                ? ((date("Y") - $birthDate[2]) - 1)
                                                : (date("Y") - $birthDate[2]));
                                            echo $age;

                                            ?></td>
                                        <td><?= $values->sex; ?></td>
                                        <td><?= $values->occupation; ?></td>

                                        <td><?= $values->fullnamen; ?></td>
                                        <td><?php $dde = $values->hmo_id; if($dde<0){echo 'Private | Company';}else{echo 'HMO';} ?></td>
                                        <td><?= $values->status_out; ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <button data-toggle="dropdown"
                                                        class="btn btn-primary btn-sm dropdown-toggle font-weight-bold btn-rounded btn-outline">
                                                    Action
                                                </button>
                                                <ul class="dropdown-menu">

                                                    <li>
                                                        <a href="host_patients_folder.php?aset=<?= base64_encode($values->id); ?>"
                                                           class="dropdown-item font-weight-bold edit_asset">View
                                                            Folder</a></li>

                                                    <li>
                                                        <a href="#?aset=<?= base64_encode($values->id); ?>"
                                                           class="dropdown-item font-weight-bold edit_asset">Close
                                                            Folder</a></li>


                                                </ul>
                                            </div>

                                        </td>
                                    </tr>
                                    <?php
                                }
                                ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" value="<?= $hos_key; ?>" id="host_key">
        <?php
        include_once "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- iCheck -->
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script src="js/plugins/dataTables/datatables.min.js"></script>


<script>

    // Upgrade button class name
    $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

    $(document).ready(function () {
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                // { extend: 'copy'},
            ]

        });

    });

</script>

<script>
    $(document).ready(function () {

        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
</script>
</body>

</html>


