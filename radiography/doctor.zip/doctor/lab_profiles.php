<?php
include_once "inc/session.php";
include_once "inc/controller.php";
include_once "inc/user_data.php";
include_once "inc/site_controller.php";
$add_user = new controller;
$get_asset_id = base64_decode($add_user->get_request('aset'));
$patients_profile = $add_user->edit_patients($hos_key,$get_asset_id);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Patient profile | Information</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <style>
        body, h1, h2, h3, h4, h5, h6  {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>

<body>

<div id="wrapper">

    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>

        <div class="wrapper wrapper-content">
            <div class="row">
                <div class="col-lg-2">
                    <?php
                    include_once "inc/casenote_menu.php";
                    ?>
                </div>
                <div class="col-lg-10 animated fadeInRight">
                    <div class="mail-box-header">

                        <h2>
                            <h2 class="font-weight-bold"><img src="doc_icon.png" height="50"> Patient's  / lab Folder</h2>
                            <a href="dashboard.php"> <span class="text-danger font-weight-bold">User Dashboard</span></a>
                        </h2>
                        <div class="mail-tools tooltip-demo m-t-md">
                            <div class="btn-group float-right">

                            </div>

                        </div>
                    </div>


                    <div class="wrapper wrapper-content animated fadeInRight">


                        <div class="row m-b-lg m-t-lg">
                            <div class="col-md-6">

                                <div class="profile-image">
                                    <img src="lab.png" class="rounded-circle circle-border m-b-md" alt="profile">
                                </div>
                                <div class="profile-info">
                                    <div class="">
                                        <div>
                                            <h2 class="no-margins font-weight-bold" style="text-transform: capitalize">
                                                <?= $patients_profile->patient_name;  ?>
                                            </h2>
                                            <h4>lab Folder</h4>
                                            <small>
                                                <a href="new_patient_test?aset=<?= base64_encode($get_asset_id); ?>"><button class="btn btn-primary btn-outline btn-rounded font-weight-bold">Add Lab Test</button></a>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                        <div class="row">



                            <div class="col-lg-1">



                            </div>
                            <div class="col-lg-9 m-b-lg">
                                <div id="vertical-timeline" class="vertical-container light-timeline no-margins">

                                    <?php
                                    $all_appoints = $add_user->ptestlist($hos_key,$get_asset_id);
                                    foreach ($all_appoints as $key=> $ad){
                                    ?>
                                    <div class="vertical-timeline-block">
                                        <div class="vertical-timeline-icon navy-bg">
                                            <i class="fa fa-check-circle"></i>
                                        </div>

                                        <div class="vertical-timeline-content">
                                            <h2><?= $ad->case_name;  ?></h2>
                                            <p><?= $ad->category_name;  ?>
                                            </p>
                                            <p class="text-success"><span class="fa fa-clock-o"></span> <?= $ad->status;  ?></p>
                                            <?php
                                            if($ad->status !='completed'){
                                               echo'<a class="btn btn-sm btn-primary btn-outline btn-rounded font-weight-bold"> Awaiting Result</a>';
                                            }else{
                                               // echo'<a class="btn btn-sm btn-primary btn-outline btn-rounded font-weight-bold"> View Result</a>';
                                            }
                                            ?>
                                            <a href="view_result.php?aset=<?=  base64_encode($ad->cb);  ?>&&caseid=<?=  base64_encode($ad->id);  ?>&&cn=<?= base64_encode($ad->case_name);  ?>" >Open Result</a>
                                            <h3>Lab Test Indication</h3>
                                            <p><?= $ad->test_note;  ?></p>

                                            <span class="vertical-date">
                                        Created Date <br>
                                        <small><?= $ad->date_added;  ?></small>
                                    </span>
                                        </div>
                                    </div>

                                    <?php
                                    }
                                    ?>
                                </div>

                            </div>

                        </div>

                    </div>




                </div>
            </div>
        </div>
        <input type="hidden" value="<?= $hos_key; ?>" id="host_key">
        <?php
        include_once "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- iCheck -->
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script src="js/plugins/dataTables/datatables.min.js"></script>


<script>

    // Upgrade button class name
    $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

    $(document).ready(function(){
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [

            ]

        });

    });

</script>

<script>
    $(document).ready(function () {

        $("#add_dpt").click(function () {
            // get the para from data-
            const department_name = $("#department_name").val();
            const host_key = $("#host_key").val();

            if(department_name=== ''){
                swal("Not allowed !", "Department Name Needed!", "error");
            }else{
                $.ajax({
                    url: "ajax/add_lab_dpt.php",
                    method: "GET",
                    data: {
                        department_name: department_name,host_key:host_key
                    },
                    success: function (data) {
                        swal("Good job!", "Lab Department Created!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);

                        if (data.trim() == 'done') {

                        }
                    }
                });
            }

        });


        $("#add_lab_test").click(function () {
            // get the para from data-
            const testname = $("#testname").val();
            const dpt = $("#dpt").val();
            const restri = $("#restri").val();
            const amount = $("#amount").val();
            const container = $("#container").val();
            const sample = $("#sample").val();
            const tat = $("#tat").val();
            const host_key = $("#host_key").val();

            if(testname=== ''){
                swal("Empty fields!", "Try Again!", "error");
            }else{
                $.ajax({
                    url: "ajax/add_test_list.php",
                    method: "GET",
                    data: {
                        testname: testname,dpt:dpt,host_key:host_key,restri:restri,amount:amount,container:container,sample:sample,tat:tat
                    },
                    success: function (data) {
                        swal("Good job!", "Test Case Added!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);

                        if (data.trim() == 'done') {

                        }
                    }
                });
            }

        });


        $(".cc").click(function () {

            // get the para from data-
            const host_fib = $(this).attr("data-id");
            $.ajax({
                url: "ajax/delete_appointment",
                method: "GET",
                data: {
                    host_fib: host_fib,
                },
                success: function (data) {
                    swal("Good job!", "This appointment Has Been Removed", "success");
                    setTimeout(
                        function () {
                            location.reload();
                        }, 3000);

                    if (data.trim() == 'done') {

                    }
                }
            });
        });


        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
</script>

<script>
    $(document).ready(function () {
        /* function to login user */
        $("#submitForm").on('submit',(function(e) {
            e.preventDefault();
            var btn = $("#reset-btn");
            btn.attr('disabled', true).html("<i class='fa fa-spin fa-spinner'></i> processing");
            var datas = new FormData(this);
            $.ajax({
                url: "ajax/add_appointment",
                type: "POST",
                data: datas,
                contentType: false,
                cache: false,
                processData:false,
                success: (data)=> {

                    if(data.trim() == "done"){
                        swal("Good job!", "Appointment Created!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);
                    }else{
                    }
                },

            });
        }));

    });
</script>
</body>

</html>

<div class="modal inmodal" id="myModal22" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content animated flipInY">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span
                        class="sr-only">Close</span></button>
                <p class="modal-title font-weight-bold">Add Appointment</p>
                <!--                <small class="font-bold">You can add and assign Lab to department.</small>-->
            </div>
            <div class="modal-body">
                <form method="POST" id="submitForm">
                <div class="form-group row">

                    <div class="col-sm-12">
                        <div class="form-group"><label class="font-weight-bold">Appointment Tittle</label> <input
                                type="text"
                                placeholder="Appointment Tittle"
                                class="form-control"
                                name="tittle" required>
                        </div>

                        <div class="form-group"><label class="font-weight-bold">Appointment Descriptions</label> <input
                                type="text"
                                placeholder="Descriptions"
                                class="form-control"
                                name="description" required>
                        </div>

                        <div class="form-group"><label class="font-weight-bold">Appointment Date / Time</label> <input
                                type="datetime-local" required
                                class="form-control"
                                name="dated">
                        </div>

                        <input type="hidden" value="<?= $get_asset_id; ?>" name="pid">

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white btn-rounded" data-dismiss="modal">Close</button>
                <input type="submit"
                       class="font-weight-bold btn btn-primary btn-outline btn-rounded pull-right"
                       value="Add Appointment" id="reset-btn">
            </div>
        </div>

    </form>
    </div>
</div>

