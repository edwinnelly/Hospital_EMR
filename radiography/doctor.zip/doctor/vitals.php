<?php
include_once "inc/session.php";
include_once "inc/controller.php";
include_once "inc/user_data.php";
include_once "inc/site_controller.php";
$add_user = new controller;
 $get_asset_id = ($add_user->get_request('aset'));
$patients_profile = $add_user->edit_patients($hos_key,$get_asset_id);
//var_dump($patients_profile);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Patient Encounters Note</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <style>
        body, h1, h2, h3, h4, h5, h6  {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>

<body>

<div id="wrapper">

    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>

        <div class="wrapper wrapper-content">
            <div class="row">
                <div class="col-lg-2">
                    <?php
                    include_once 'inc/counter_menu.php';
                    ?>
                </div>
                <div class="col-lg-10 animated fadeInRight">
                    <div class="mail-box-header">

                        <h2>
                            <h2 class="font-weight-bold"><img src="https://img.icons8.com/cotton/344/protection-mask--v13.png" height="50"> Patient Vitals Reports</h2>
<!--                            <span class="text-danger">Patient Encounters</span><br>-->
                            <a href="edit_patients.php?aset=<?= base64_encode($get_asset_id);  ?>"><a href="add_vitals.php?aset=<?= base64_encode($get_asset_id);  ?>"> <span class="font-weight-bold btn-outline btn-rounded btn-sm btn btn-primary">Add Vitals Reports</span></a></a>
                            <a href="host_patients_folder.php?aset=<?= base64_encode($get_asset_id);  ?>"> <span class="font-weight-bold btn-outline btn-rounded btn-sm btn btn-primary">Patient Folder</span></a>
                        </h2>
                        <div class="mail-tools tooltip-demo m-t-md">
                            <div class="btn-group float-right">

                            </div>

                        </div>
                    </div>


                    <div class="wrapper wrapper-content animated fadeInRight">



                        <div class="row">

                            <div class="row">
                                <div class="col-lg-12">
                                    <?php
                                    $all_vitals = $add_user->all_vitals($get_asset_id);
                                    foreach ($all_vitals as $key=> $vitals){
                                    ?>
                                    <div class="panel panel-default">

                                        <div class="panel-heading font-weight-bold">
                                            Vitals
                                        </div>
                                        <div class="panel-body">


                                            <table class="table small m-b-xs">
                                                <tbody>
                                                <tr>
                                                    <td>
                                                        <strong>Weight</strong> -<?= $vitals->weight; ?>Kg
                                                    </td>
                                                    <td>
                                                        <strong>Height</strong> -<?= $vitals->height; ?>cm
                                                    </td>
                                                    <td>
                                                        <strong> Blood Pressure</strong> -<?= $vitals->blood_Pressure; ?>mmHg
                                                    </td>
                                                    <td>
                                                        <strong>  Body Temperature</strong> -<?= $vitals->body_Temperature; ?>°C
                                                    </td>
                                                    <td>
                                                        <strong>Pulse Rate</strong> -<?= $vitals->heart_Rate; ?>BPM
                                                    </td>
                                                    <td>
                                                        <strong>  Respiratory Rate</strong> -<?= $vitals->respiratory_Rate; ?>cpm
                                                    </td><td>
                                                        <strong>  Oxygen Saturation</strong> -<?= $vitals->oxygen_Saturation; ?>%
                                                    </td>

                                                </tr>
                                                <tr>
                                                    <td>
                                                        <strong>Random Blood Sugar</strong> -<?= $vitals->random_Blood; ?>mmol/L
                                                    </td>
                                                    <td>
                                                        <strong>Abdominal Girth</strong> -<?= $vitals->fbdominal_Girth; ?>cm
                                                    </td>
                                                    <td>
                                                        <strong>  Fasting Blood Sugar</strong> -<?= $vitals->fasting_Blood_Sugar; ?>mmol/L
                                                    </td>
                                                    <td>
                                                        <strong>  Head Circumference</strong> -<?= $vitals->head_Circumference; ?>cm
                                                    </td>
                                                    <td>
                                                        <strong> Chest Circumference</strong> -<?= $vitals->chest_Circumference; ?>cm
                                                    </td>
                                                    <td>
                                                        <strong>  Mac</strong> -<?= $vitals->mac; ?>cm
                                                    </td><td>
                                                        <strong>   Subscapular Skinfold</strong> -<?= $vitals->subscapular_Skinfold; ?>mm
                                                    </td></td><td>
                                                        <strong>   Subscapular Skinfold</strong> -<?= $vitals->triceps_Skinfold; ?>mm
                                                    </td>

                                                </tr>

                                                </tbody>
                                            </table>


                                        </div>


                                        <div class="social-footer">

                                            <div class="social-comment">
                                                <a href="" class="float-left">
                                                    <img alt="image" src="bell.png">
                                                </a>
                                                <div class="media-body">
                                                    <a href="">
                                                        Additional Notes                                             </a>
                                                    <?= $vitals->notes; ?>                                             <br>

                                                    <small class="text-muted"> <?= $vitals->dated; ?></small>
                                                </div>
                                            </div>

                                        </div>

                                        <div class="panel-footer">
                                            Posted By <?= $vitals->fullname; ?> <a href="edit_vitals.php?aset=<?= base64_encode($vitals->id); ?>&&pid=<?= $get_asset_id;  ?>"> <button class="btn btn-default btn-sm btn-rounded fa fa-edit"></button></a><span class="fa fa-recycle cc" data-id="<?= $vitals->id; ?>"></span><span class="pull-right font-weight-bold" style="font-size: 14px;"><?= $vitals->dated; ?></span>
                                        </div>

                                    </div>
                                    <?php
                                    }
                                    ?>


                                </div>


                            </div>

                        </div>

                    </div>




                </div>
            </div>
        </div>
        <input type="hidden" value="<?= $hos_key; ?>" id="host_key">
        <?php
        include_once "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- iCheck -->
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script src="js/plugins/dataTables/datatables.min.js"></script>
<script src="https://cdn.lordicon.com/lusqsztk.js"></script>

<script>

    // Upgrade button class name
    $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

    $(document).ready(function(){
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [

            ]

        });

    });

</script>

<script>
    $(document).ready(function () {

        $(document).on('click', '.add_cc', function() {
            // get the para from data-
            const comments = $(".comments").val();
            const enid = $(this).attr("data-enid");
            const doc = $(this).attr("data-doc");

            if(comments=== 0){
                swal("Not allowed !", "Comments Needed!", "error");
            }else{
                $.ajax({
                    url: "ajax/add_encounter_comments.php",
                    method: "GET",
                    data: {
                        comments: comments,enid:enid
                    },
                    success: function (data) {

                        swal("Good job!", "Comments Added!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);

                        if (data.trim() == 'done') {

                        }
                    }
                });
            }

        });


        $(".cc").click(function () {

            // get the para from data-
            const host_fib = $(this).attr("data-id");
            $.ajax({
                url: "ajax/delete_vital",
                method: "GET",
                data: {
                    host_fib: host_fib,
                },
                success: function (data) {
                    swal("Good job!", "This Vital Report Has Been Removed", "success");
                    setTimeout(
                        function () {
                            location.reload();
                        }, 3000);

                    if (data.trim() == 'done') {

                    }
                }
            });
        });

        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
</script>
</body>

</html>



