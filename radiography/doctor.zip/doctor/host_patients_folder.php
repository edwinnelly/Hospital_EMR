<?php
include_once "inc/session.php";
include_once "inc/controller.php";
include_once "inc/user_data.php";
include_once "inc/site_controller.php";
$add_user = new controller;
$get_asset_id = base64_decode($add_user->get_request('aset'));
$patients_profile = $add_user->edit_patients($hos_key,$get_asset_id);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Patient profile | Information</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <style>
        body, h1, h2, h3, h4, h5, h6  {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>

<body>

<div id="wrapper">

    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>

        <div class="wrapper wrapper-content">
            <div class="row">
                <div class="col-lg-2">
                    <?php
                    include_once "inc/casenote_menu.php";
                    ?>
                </div>
                <div class="col-lg-10 animated fadeInRight">
                    <div class="mail-box-header">

                        <div class="row m-b-lg m-t-lg">
                            <div class="col-md-6">

                                <div class="profile-image">
                                    <img src="https://img.icons8.com/cute-clipart/344/cloud-folder.png" class="rounded-circle circle-border m-b-md" alt="profile">
                                </div>
                                <div class="profile-info">
                                    <div class="">
                                        <div>
                                            <h2 class="no-margins font-weight-bold">
                                                <?= $patients_profile->patient_name;  ?>
                                            </h2>
                                            <h4>Patient Profile</h4>
                                            <table class="table small m-b-xs">
                                                <tbody>
                                                <tr>
                                                    <td>
                                                        <strong>Address</strong>-
                                                    </td>
                                                    <td>
                                                        <strong>SOS Phone</strong> -
                                                    </td>

                                                </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <table class="table small m-b-xs">
                                    <tbody>
                                    <tr>
                                        <td>
                                            <strong>Gender</strong> -
                                        </td>
                                        <td>
                                            <strong>Age</strong> -
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Marital Status</strong>-
                                        </td>
                                        <td>
                                            <strong>Phone</strong> -
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Next Of Kin</strong> -
                                        </td>
                                        <td>
                                            <strong>Created Date</strong> -
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-3">
                                <strong><img src="https://img.icons8.com/cute-clipart/344/us-dollar-circled.png" height="70">  </strong>
                                <h4 class="no-margins font-weight-bold"> ₦<?= number_format($patients_profile->wallet,2);  ?></h4>
                                <div id="sparkline1"><canvas style="display: inline-block; width: 428.53px; height: 50px; vertical-align: top;" width="428" height="50"></canvas></div>
                            </div>


                        </div>


                    </div>


                    <div class="wrapper wrapper-content animated fadeInRight">


                        <div class="row m-b-lg m-t-lg">
                            <div class="col-md-6">

                                <div class="profile-image">
                                    <img src="img/log.png" class="rounded-circle circle-border m-b-md" alt="profile">
                                </div>
                                <div class="profile-info">
                                    <div class="">
                                        <div>
                                            <h2 class="no-margins font-weight-bold" style="text-transform: capitalize">
                                               <?= $patients_profile->patient_name;  ?>
                                            </h2>
                                            <h4>Appointment / Bookings</h4>

                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                        <div class="row">



                            <div class="col-lg-1">



                            </div>
                            <div class="col-lg-9 m-b-lg">
                                <div id="vertical-timeline" class="vertical-container light-timeline no-margins">

                                    <?php
                                    $all_appoints = $add_user->all_appoints($get_asset_id,$user_id);
                                    foreach ($all_appoints as $key=> $ad){
                                        ?>
                                        <div class="vertical-timeline-block">
                                            <div class="vertical-timeline-icon navy-bg">
                                                <i class="fa fa-bell"></i>
                                            </div>

                                            <div class="vertical-timeline-content">
                                                <h2 style="font-weight: 700;"><?= $ad->tittle;  ?></h2>
                                                <p><?= $ad->description;  ?>
                                                </p>
                                                <p><?= $ad->fullname;  ?></p>
                                                <span class="vertical-date">
                                        Appointment Date <br>
                                        <small><?= $ad->dated;  ?></small>
                                    </span>
                                            </div>
                                        </div>

                                        <?php
                                    }
                                    ?>
                                </div>

                            </div>

                        </div>

                    </div>




                </div>
            </div>
        </div>
        <input type="hidden" value="<?= $hos_key; ?>" id="host_key">
        <?php
        include_once "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- iCheck -->
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script src="js/plugins/dataTables/datatables.min.js"></script>


<script>

    // Upgrade button class name
    $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

    $(document).ready(function(){
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [

            ]

        });

    });

</script>

<script>
    $(document).ready(function () {

        $("#add_dpt").click(function () {
            // get the para from data-
            const department_name = $("#department_name").val();
            const host_key = $("#host_key").val();

            if(department_name=== ''){
                swal("Not allowed !", "Department Name Needed!", "error");
            }else{
                $.ajax({
                    url: "ajax/add_lab_dpt.php",
                    method: "GET",
                    data: {
                        department_name: department_name,host_key:host_key
                    },
                    success: function (data) {
                        swal("Good job!", "Lab Department Created!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);

                        if (data.trim() == 'done') {

                        }
                    }
                });
            }

        });


        $("#add_lab_test").click(function () {
            // get the para from data-
            const testname = $("#testname").val();
            const dpt = $("#dpt").val();
            const restri = $("#restri").val();
            const amount = $("#amount").val();
            const container = $("#container").val();
            const sample = $("#sample").val();
            const tat = $("#tat").val();
            const host_key = $("#host_key").val();

            if(testname=== ''){
                swal("Empty fields!", "Try Again!", "error");
            }else{
                $.ajax({
                    url: "ajax/add_test_list.php",
                    method: "GET",
                    data: {
                        testname: testname,dpt:dpt,host_key:host_key,restri:restri,amount:amount,container:container,sample:sample,tat:tat
                    },
                    success: function (data) {
                        swal("Good job!", "Test Case Added!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);

                        if (data.trim() == 'done') {

                        }
                    }
                });
            }

        });


        $(".del_lab_dpt").click(function () {

            // get the para from data-
            const host_fib = $(this).attr("data-id");
            $.ajax({
                url: "ajax/d_lab_dpt.php",
                method: "GET",
                data: {
                    host_fib: host_fib,
                },
                success: function (data) {
                    swal("Good job!", "This Lab Department Has Been Removed", "success");
                    setTimeout(
                        function () {
                            location.reload();
                        }, 3000);

                    if (data.trim() == 'done') {

                    }
                }
            });
        });


        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
</script>
</body>

</html>



