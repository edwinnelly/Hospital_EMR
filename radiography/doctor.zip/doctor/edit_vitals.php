<?php
include_once "inc/session.php";
include_once "inc/controller.php";
include_once "inc/user_data.php";
include_once "inc/site_controller.php";
$add_user = new controller;
 $get_asset_id = base64_decode($add_user->get_request('aset'));
  $pid_id = ($add_user->get_request('pid'));
$vitals = $add_user->edit_vital_categ($get_asset_id);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Vitals reports| Controls</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        body, h1, h2, h3, h4, h5, h6 {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>
<body>
<div id="wrapper">
    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>

        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-10">
                <h2 class="font-weight-bold">Patient's Vitals Report</h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a>Forms</a>
                    </li>
                    <li class="breadcrumb-item active">
                        <strong>New</strong>
                    </li>
                </ol>
            </div>
            <div class="col-lg-2">

            </div>
        </div>

        <div class="wrapper wrapper-content">
            <div class="row">


                <div class="col-lg-12 animated fadeInRight">
                    <div class="mail-box-header">


                        <div class="mail-tools tooltip-demo m-t-md">

                            <h3 class="text-primary" style="text-transform: capitalize;margin-left: 20px;">You are
                                Editing patient's Vitals Reports</h3>
                            <a href="vitals?aset=<?= $pid_id; ?>"> <button class="font-weight-bold btn btn-danger btn-outline btn-rounded pull-right">Back to Vitals</button></a>
                        </div>
                    </div>
                    <div class="mail-box">
                        <div class="ibox-content table-responsive">
                            <h4 class="font-weight-bold">

                                <form method="POST" id="submitForm">
                                    <div class="form-group row">
                                        <div class="col-sm-8">
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Weight</label>
                                                        <input type="text" name="weight" value="<?= $vitals->weight;  ?>" required maxlength="4" class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Height </label>
                                                        <input type="text" value="<?= $vitals->height;  ?>" name="height" required class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Blood Pressure</label>
                                                        <input type="text" name="bp" value="<?= $vitals->blood_Pressure;  ?>" required class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Body Temperature</label>
                                                        <input type="text" value="<?= $vitals->body_Temperature;  ?>" name="bt" required class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Heart Rate</label>
                                                        <input type="text" name="heartr" value="<?= $vitals->heart_Rate;  ?>" required class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Respiratory Rate</label>
                                                        <input type="text" name="r_rate" value="<?= $vitals->respiratory_Rate;  ?>" required class="form-control">
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-8">
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Oxygen Saturation</label>
                                                        <input type="text" name="oxygens" value="<?= $vitals->oxygen_Saturation;  ?>" required class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Random Blood Sugar </label>
                                                        <input type="text" value="<?= $vitals->random_Blood;  ?>" name="randombs" required class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Abdominal Girth</label>
                                                        <input type="text" name="abdominalg" value="<?= $vitals->fbdominal_Girth;  ?>" required class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Fasting Blood Sugar</label>
                                                        <input type="text" name="fasting_bs" value="<?= $vitals->fasting_Blood_Sugar;  ?>" required class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Head Circumference</label>
                                                        <input type="text" name="h_circumference" value="<?= $vitals->head_Circumference;  ?>" required class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="form-group"><label>Chest Circumference</label>
                                                        <input type="text" name="chest_c" value="<?= $vitals->chest_Circumference;  ?>" required class="form-control">
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="mail-box">
                                        <div class="ibox-content table-responsive">
                                            <h4 class="font-weight-bold">

                                                <div class="form-group row">
                                                    <div class="col-sm-8">
                                                        <div class="row">
                                                            <div class="col-md-2">
                                                                <div class="form-group"><label>MAC </label>
                                                                    <input type="text" required name="mac" value="<?= $vitals->mac;  ?>" class="form-control">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-2">
                                                                <div class="form-group"><label>Subscapular
                                                                        Skinfold </label>
                                                                    <input type="text" value="<?= $vitals->subscapular_Skinfold;  ?>" required name="subscapular"
                                                                           class="form-control">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-2">
                                                                <div class="form-group"><label>Triceps Skinfold</label>
                                                                    <input type="text" value="<?= $vitals->triceps_Skinfold;  ?>" required name="triceps"
                                                                           class="form-control">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-2">
                                                                <div class="form-group"><label>Additional Notes</label>
                                                                    <input type="text" value="<?= $vitals->notes;  ?>" required name="additional" id="additional"
                                                                           class="form-control">
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                                <input type="hidden" value="<?= $get_asset_id; ?>" name="patient_id">
                                                <input type="hidden" value="<?= $vitals->id;  ?>" name="vid">

                                                <input type="submit"
                                                       class="font-weight-bold btn btn-primary btn-outline btn-rounded pull-right"
                                                       value="Update Vitals" id="reset-btn">
                                            </h4>

                                        </div>
                                    </div>
                                </form>




                        </div>


                    </div>
                </div>

                <?php
                include_once "inc/footer.php";
                ?>
            </div>
        </div>

        <!-- Mainly scripts -->
        <script src="js/jquery-3.1.1.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
        <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

        <!-- Custom and plugin javascript -->
        <script src="js/inspinia.js"></script>
        <script src="js/js_hospital.js"></script>
        <script src="js/plugins/pace/pace.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

        <!-- iCheck -->
        <script src="js/plugins/iCheck/icheck.min.js"></script>
        <script src="js/plugins/dataTables/datatables.min.js"></script>
        <script src="https://cdn.lordicon.com/lusqsztk.js"></script>

        <script>
            $(document).ready(function () {

                /* function to login user */
                $("#submitForm").on('submit',(function(e) {
                    e.preventDefault();
                    var btn = $("#reset-btn");
                    btn.attr('disabled', true).html("<i class='fa fa-spin fa-spinner'></i> processing");
                    var datas = new FormData(this);
                    $.ajax({
                        url: "ajax/edit_vital",
                        type: "POST",
                        data: datas,
                        contentType: false,
                        cache: false,
                        processData:false,
                        success: (data)=> {
                            if(data.trim() == "done"){
                                swal("Good job!", "Vitals Updated!", "success");
                                setTimeout(
                                    function () {
                                        location.reload();
                                    }, 3000);
                            }else{

                            }
                        },

                    });
                }));




            });
        </script>
</body>

</html>

