<?php
include "inc/site_controller.php";
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>App Settings | Controls</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <style>
        body, h1, h2, h3, h4, h5, h6  {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>

<body>

<div id="wrapper">

    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>
        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-10">
                <h3 class="font-weight-bold">Add Patient's Profile</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a>Data</a>
                    </li>
                    <li class="breadcrumb-item active">
                        <strong>Hospital Data</strong>
                    </li>
                    <li class="breadcrumb-item active">
                        <a href="setup_patients.php"><button class="btn btn-primary btn-rounded btn-outline font-weight-bold">Patients List</button></a>
                    </li>
                </ol>
            </div>
            <div class="col-lg-2">
                <!--                    <button class="btn btn-success btn-rounded">New Hospitals</button>-->
            </div>
        </div>
        <div class="wrapper wrapper-content animated fadeInDown">
            <div class="row">
                <div class="col-lg-8">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5 class="font-weight-bold">Open New Account / Profile</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>


                            </div>
                        </div>
                        <div class="ibox-content">


                                <div class="form-group"><label>Patient's Fullname</label> <input type="text"
                                                                                                placeholder="Patient's Fullname"
                                                                                                class="form-control"
                                                                                                id="fullname">
                                </div>

                                <div class="form-group"><label>Patient's Age</label> <input type="date"
                                                                                                 placeholder="Age"
                                                                                                 class="form-control"
                                                                                                 id="age"
                                                                                                 >
                                </div>

                                <div class="form-group"><label>Sex</label> <input  type="text"
                                                                                                 placeholder="Sex"
                                                                                                 class="form-control" id="sex"

                                    >
                                </div>

                                <div class="form-group"><label>Occupation</label> <input  type="text"
                                                                                         placeholder="Occupation"
                                                                                         class="form-control" id="occupation"

                                                                                         >
                                </div>


                            <div class="form-group"><label>Marital Status</label> <input  type="text"
                                                                                      placeholder="Marital Status"
                                                                                      class="form-control" id="marital_status"

                                >
                            </div>


                            <div class="form-group"><label>Address</label> <input  type="text"
                                                                                          placeholder="Address"
                                                                                          class="form-control" id="address"

                                >
                            </div>


                            <div class="form-group"><label>Tribe</label> <input  type="text"
                                                                                   placeholder="Tribe"
                                                                                   class="form-control" id="tribe"

                                >
                            </div>



                            <div class="form-group"><label>Religion</label> <input  type="text"
                                                                                 placeholder="Religion"
                                                                                 class="form-control" id="religion"

                                >
                            </div>


                            <div class="form-group"><label>Next of kin</label> <input  type="text"
                                                                                    placeholder="Next of kin"
                                                                                    class="form-control" id="next_of_kin"

                                >
                            </div>


                            <div class="form-group"><label>Phone Number</label> <input  type="text"
                                                                                       placeholder="phone Number"
                                                                                       class="form-control" id="phone_number"

                                >
                            </div>


                            <div class="form-group"><label>Email Address</label> <input  type="text"
                                                                                        placeholder="Email Address"
                                                                                        class="form-control" id="email"

                                >
                            </div>




                                <div class="form-group"><label>Added Date</label> <input  type="date"
                                                                                                                          placeholder="Added date"
                                                                                         class="form-control" id="rg_date"
                                                                                         >
                                </div>

                            <div class="form-group"><label>Private</label>
                                <select class="form-control" id="acc_type">
                                    <option value="1">VIP</option>
                                    <option value="2">Standard </option>
                                    <option value="3">Regular</option>
                                </select>
                            </div>

                            <div class="form-group"><label>HMO</label>
                                <select class="form-control" id="hmo">
                                    <option value="0">Choose Hmo</option>
                                    <option value="1">Standard </option>

                                </select>
                            </div>

                            <div class="form-group"><label>RETAINER</label>
                                <select class="form-control" id="retain_type">
                                    <option value="0">Choose Hmo</option>
                                    <option value="1">INDIVIDUAL </option>
                                    <option value="2">FAMILY </option>
                                    <option value="3">ORGANIZATION </option>

                                </select>
                            </div>

                                <div>
                                    <button class="btn btn-sm btn-primary btn-rounded font-weight-bold btn-outline float-right m-t-n-xs"
                                            type="submit" id="add_ac"><strong>Add
                                            Patient</strong></button>
                                </div>


                            <br>
                            <br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        include "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<script src="js/plugins/dataTables/datatables.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>

<!-- Page-Level Scripts -->
<script>

    // Upgrade button class name
    $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

    $(document).ready(function () {
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                // { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {
                    extend: 'print',
                    customize: function (win) {
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });

    });

</script>
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script>
    $(document).ready(function () {
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
</script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</body>

</html>
