<div class="footer">
    <div class="float-right">
      Med Portal
    </div>
    <div>
        <strong>Copyright</strong> Maxsom &copy; 2021-2022
    </div>
</div>