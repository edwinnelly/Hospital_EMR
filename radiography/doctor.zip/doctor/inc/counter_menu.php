<div class="ibox ">
    <div class="ibox-content mailbox-content">
        <div class="file-manager">
            <!--            <a class="btn btn-block btn-primary compose-mail font-weight-bold btn-rounded" href="">Module-->
            <!--                Settings</a>-->
            <div class="space-25"></div>
            <h3 class="font-weight-bold"><img src="https://img.icons8.com/cotton/344/avoid-touching--v2.png" height="50"> Patient's Case Note</h3>
            <ul class="folder-list m-b-md" style="padding: 0;font-weight: 600;">

                <li><a href="casenote.php?aset=<?= $get_asset_id; ?>"> <i class="fa fa-circle-o"></i>Encounters</a></li>
                <li><a href="vitals.php?aset=<?= $get_asset_id; ?>"> <i class="fa fa-circle text-danger"></i>Vitals</a></li>
                <li><a href="clinical_note.php?aset=<?= $get_asset_id; ?>"> <i class="fa fa-circle text-danger"></i>Clinical Note</a></li>

                <li><a href="fluids.php?aset=<?= $get_asset_id; ?>"> <i class="fa fa-circle-o text-danger"></i>Fluid Chart</a></li>
<!--                <li><a href="#"> <i class="fa fa-circle-o text-danger"></i>Nursing Remark</a></li>-->
                <li><a href="surgical_note.php?aset=<?= $get_asset_id; ?>"> <i class="fa fa-circle text-danger"></i>Surgical note</a></li>

                <li><a href=""> <i class="fa fa-circle text-danger"></i>Results</a></li>
<!--                <li><a href="app_settings.php"> <i class="fa fa-circle-o text-danger"></i>Immunizations</a></li>-->
                <li><a href="comment_notes.php?aset=<?= $get_asset_id; ?>"> <i class="fa fa-circle text-primary"></i>Comments</a>
                </li>
            </ul>




            <div class="clearfix"></div>
        </div>
    </div>
</div>