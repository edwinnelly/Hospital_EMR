    <?php
    /** Database connection credentials for localhost **/
    define("host", "localhost");
    define("user", "funfsvly_ckudodoctor");
    define("password", "4Pr*16J_JC4S");
    define("database", "funfsvly_deploy_hospital");
    define("apikey", "");



//    define("host", "localhost");
//    define("user", "maxsmpyv_dr_ck_udo");
//    define("password", "Ai?e9ScpFum5");
//    define("database", "maxsmpyv_lab_ck_db");
//    define("apikey", "");
//



    ?>



