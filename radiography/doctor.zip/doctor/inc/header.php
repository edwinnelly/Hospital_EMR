<nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <a class="navbar-minimalize minimalize-styl-2" href="#"><img
                    src="./img/cc.png"
                    alt="morph-two-way"
                    style="width:40px;height:40px">
        </a>

    </div>
    <ul class="nav navbar-top-links navbar-right">
        <li>
            <span class="m-r-sm text-muted welcome-message font-weight-bold">Welcome to Maxsom+ Med Portal.</span>
        </li>


        <li>
            <a href="inc/logout.php">
                <i class="fa fa-power-off"></i> Log out
            </a>
        </li>

    </ul>

</nav>