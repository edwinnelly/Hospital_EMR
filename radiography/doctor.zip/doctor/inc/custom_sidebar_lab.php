<div class="ibox ">
    <div class="ibox-content mailbox-content">
        <div class="file-manager">
<!--            <a class="btn btn-block btn-primary compose-mail font-weight-bold btn-rounded" href="">Module-->
<!--                Settings</a>-->
            <div class="space-25"></div>
            <h5 class="font-weight-bold">Lab Setup</h5>
            <ul class="folder-list m-b-md" style="padding: 0">
                <li><a href="lab_setup.php"> <i class="fa fa-circle-o text-success"></i>Manage Lab </a></li>
                <li><a href="dpt_tests.php"> <i class="fa fa-circle-o"></i>Dpt Test file</a></li>
                <li><a href="app_settings.php"> <i class="fa fa-circle text-danger"></i>Lab Assets</a></li>
            </ul>
            <h5>Extra Settings</h5>
            <ul class="category-list" style="padding: 0">
                <li><a href="lab_setup_e.php"> <i class="fa fa-circle text-danger"></i> Samples</a>
                </li>
                <li><a href="lab_setup_e.php"> <i class="fa fa-circle text-primary"></i> Container</a>
                </li>

            </ul>
            </ul>



            <div class="clearfix"></div>
        </div>
    </div>
</div>