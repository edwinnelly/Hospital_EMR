<?php
include_once "inc/session.php";
include_once "inc/controller.php";
include_once "inc/user_data.php";
include_once "inc/site_controller.php";
$add_user = new controller;
$user_id = $add_user->get_request('aset');
$assets_list = $add_user->drugs_ls($hos_key);
$assets_list_n = $add_user->hospital_list_assets($hos_key);

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Patient profile | PRESCRIPTIONS</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <style>
        body, h1, h2, h3, h4, h5, h6 {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>

<body>

<div id="wrapper">

    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>

        <div class="wrapper wrapper-content">
            <div class="row">

                <div class="col-lg-10 animated fadeInRight">
                    <div class="mail-box-header">

                        <h2>
                            <h3 class="font-weight-bold" style="text-transform: uppercase"> Drug administration</h3>
                        </h2>
                        <a href="host_patients_folder.php?aset=<?= base64_encode($user_id); ?>"> <button class="btn-sm font-weight-bold btn btn-outline btn-primary btn-rounded pull-right">Patient Profile
                            </button></a>
                    </div>
                    <div class="mail-box">
                        <div class="ibox-content table-responsive">

                            <table class="table table-hover table-mail dataTables-example">
                                <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Drugs Name</th>
                                    <th>Frequency</th>
                                    <th>Duration</th>
                                    <th>Quantity</th>
                                    <th>Added Date</th>
                                    <th>Med Status</th>
                                    <th>Status</th>

                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php

                                $cc = $add_user->ps_drugsn($hos_key);
                                $i = 0;
                                foreach ($cc as $key => $values) {
                                    $i++;
                                    ?>
                                    <tr class="gradeA">
                                        <td><?= $i; ?></td>
                                        <td><?= $values->drugs_name; ?></td>
                                        <td><?php if ($values->fz_dosage == 1) {
                                                echo 'OD';
                                            } elseif($values->fz_dosage == 2) {
                                                echo 'BD';
                                            } elseif ($values->fz_dosage == 3) {
                                                echo 'TDS';
                                            } elseif ($values->fz_dosage == 4) {
                                                echo 'QDS';
                                            }elseif ($values->fz_dosage == 5) {
                                                echo 'NOCTE';
                                            }elseif ($values->fz_dosage == 6) {
                                                echo 'WEEKLY';
                                            }elseif ($values->fz_dosage == 7) {
                                                echo 'BE WEEKLY';
                                            } ?></td>
                                        <td><?= $values->duration; ?> Days</td>
                                        <td><?= $values->final_qty; ?></td>
                                        <td><?= $values->date_time; ?></td>
                                        <td><?php if($values->med_status==1){echo 'Active';}else{echo 'Inactive';} ?></td>
                                        <td><?= 'pending'; ?></td>

                                        <td>
                                            <div class="btn-group">
                                                <button data-toggle="dropdown"
                                                        class="btn btn-outline btn-primary btn-sm dropdown-toggle font-weight-bold btn-rounded">
                                                    Action
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li class="dropdown-divider"></li>

                                                    <li><a href="drug_chart.php?aset=<?= $values->drug_key; ?>&&fid=<?= base64_encode($user_id);  ?>" class="dropdown-item text-danger font-weight-bold">Drug Chart</a></li>

                                                    <li><a class="dropdown-item text-danger stop_med font-weight-bold"
                                                           data-id="<?= $values->id; ?>" data-doc="">Discontinue Medication.</a></li>

                                                </ul>
                                            </div>

                                        </td>
                                    </tr>
                                    <?php
                                }
                                ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        include_once "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- iCheck -->
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script src="js/plugins/dataTables/datatables.min.js"></script>


<script>

    // Upgrade button class name
    $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

    $(document).ready(function () {
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                // { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {
                    extend: 'print',
                    customize: function (win) {
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });

    });

</script>

<script>
    $(document).ready(function () {


        $(".del_med").click(function () {

            // get the para from data-
            const chart_id = $(this).attr("data-id");
            $.ajax({
                url: "ajax/drugs_remove.php",
                method: "GET",
                data: {
                    chart_id: chart_id
                },
                success: function (data) {

                    swal("Good job!", "Medication Removed", "success");
                    setTimeout(
                        function () {
                            location.reload();
                        }, 3000);

                    if (data.trim() == 'done') {

                    }
                }
            });
        });


        $(".stop_med").click(function () {

            // get the para from data-
            const chart_id = $(this).attr("data-id");
            $.ajax({
                url: "ajax/drugs_stop.php",
                method: "GET",
                data: {
                    chart_id: chart_id
                },
                success: function (data) {

                    swal("Good job!", "Medication Stopped", "success");
                    setTimeout(
                        function () {
                            location.reload();
                        }, 3000);

                    if (data.trim() == 'done') {

                    }
                }
            });
        });



        $("#add_sssets").click(function () {
            // get the para from data-
            const dg = $("#dg").val();
            const du = $("#du").val();
            const fz = $("#fz").val();
            const qty = $("#qty").val();
            const uid = $("#uid").val();

            if (dg === '') {
                swal("Empty fields!", "Try Again!", "error");
            } else {
                $.ajax({
                    url: "ajax/pescrib_drugs.php",
                    method: "GET",
                    data: {
                        dg: dg, du: du, fz: fz, qty: qty,uid:uid
                    },
                    success: function (data) {
                        swal("Good job!", "Drug Added!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);

                        if (data.trim() == 'done') {

                        }
                    }
                });
            }

        });


        $(".del_asset").click(function () {

            // get the para from data-
            const host_fib = $(this).attr("data-id");
            $.ajax({
                url: "ajax/d_asset.php",
                method: "GET",
                data: {
                    host_fib: host_fib,
                },
                success: function (data) {
                    swal("Good job!", "This Asset Has Been Removed", "success");
                    setTimeout(
                        function () {
                            location.reload();
                        }, 3000);

                    if (data.trim() == 'done') {

                    }
                }
            });
        });


        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
</script>
</body>

</html>


<div class="modal inmodal" id="myModal22" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content animated flipInY">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span
                        class="sr-only">Close</span></button>
                <p class="modal-title">ADD NEW PRESCRIPTIONS</p>
                <small class="font-bold">You can add and assign drugs to patient.</small>
            </div>
            <div class="modal-body">
                <div class="form-group row">

                    <div class="col-sm-12">

                        <div class="form-group"><label>Choose Drugs</label>
                            <select class="form-control" id="dg">
                                <option value="">Choose Category</option>
                                <?php
                                foreach ($assets_list as $key => $ass) {
                                    ?>
                                    <option value="<?php echo $ass->id; ?>"><?php echo $ass->drugs_name; ?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group"><label>Duration</label> <input type="text"
                                                                               placeholder="duration"
                                                                               class="form-control"
                                                                               id="du">
                        </div>


                        <div class="form-group"><label>Quantity</label> <input type="text"
                                                                               placeholder="Quantity"
                                                                               class="form-control"
                                                                               id="qty">
                        </div>

                        <input type="hidden" id="uid" value="<?= $user_id; ?>">

                        <div class="form-group"><label>Choose frequency</label>
                            <select class="form-control" id="fz">
                                <option value="1">OD</option>
                                <option value="2">BD</option>
                                <option value="3">TDS</option>
                                <option value="4">QD</option>
                                <option value="5">NOCTE</option>
                                <option value="6">WEEKLY</option>
                            </select>
                        </div>


                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline btn-white btn-rounded" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline btn-primary font-weight-bold btn-rounded" id="add_sssets">
                    Add
                </button>
            </div>
        </div>
    </div>
</div>



