<?php
include_once "inc/session.php";
include_once "inc/controller.php";
include_once "inc/user_data.php";
include_once "inc/site_controller.php";
$add_user = new controller;
 $get_asset_id = ($add_user->get_request('aset'));
$patients_profile = $add_user->edit_patients($hos_key,$get_asset_id);
//var_dump($patients_profile);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Patient Encounters Note</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <style>
        body, h1, h2, h3, h4, h5, h6  {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>

<body>

<div id="wrapper">

    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>

        <div class="wrapper wrapper-content">
            <div class="row">
                <div class="col-lg-2">
                    <?php
                    include_once 'inc/counter_menu.php';
                    ?>
                </div>
                <div class="col-lg-10 animated fadeInRight">
                    <div class="mail-box-header">

                        <h2>
                            <h2 class="font-weight-bold"><img src="doc_icon.png" height="60"> Patient Encounters Note</h2>
<!--                            <span class="text-danger">Patient Encounters</span><br>-->
                            <a href="edit_patients.php?aset=<?= base64_encode($get_asset_id);  ?>"><span class="text-primary">Update Profile</span></a>
                            <a href="host_patients_folder?aset=<?= base64_encode($get_asset_id); ?>"> <button class="font-weight-bold btn btn-danger btn-outline btn-rounded pull-right">Back to Patient Folder</button></a>
                        </h2>
                        <div class="mail-tools tooltip-demo m-t-md">
                            <div class="btn-group float-right">

                            </div>

                        </div>
                    </div>


                    <div class="wrapper wrapper-content animated fadeInRight">


                        <div class="row m-b-lg m-t-lg">
                            <div class="col-md-6">

                                <div class="profile-image">
                                    <img src="usericon.png" class="rounded-circle circle-border m-b-md" alt="profile">
                                </div>
                                <div class="profile-info">
                                    <div class="">
                                        <div>
                                            <h2 class="no-margins font-weight-bold" style="text-transform: capitalize">
                                               <?= $patients_profile->patient_name;  ?>
                                            </h2>
<!--                                            <h4>Founder of Groupeq</h4>-->
                                            <small>
                                                <?= $patients_profile->briefs;  ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <table class="table small m-b-xs">
                                    <tbody>
                                    <tr>
                                        <td>
                                            <span class="font-weight-bold">Blood Pressure</span> <strong class="text-danger"><?= $patients_profile->bp;  ?></strong>
                                        </td>
                                        <td>
                                            <span class="font-weight-bold">Heart Rate</span> <strong class="text-danger"><?= $patients_profile->heart_rate;  ?></strong>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>
                                            <span class="font-weight-bold">Body Temp</span> <strong class="text-danger"><?= $patients_profile->body_temp;  ?></strong>
                                        </td>
                                        <td>
                                            <span class="font-weight-bold">Weight</span> <strong class="text-danger"><?= $patients_profile->height;  ?></strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span class="font-weight-bold">Admission Status</span> <strong class="text-danger">Open</strong>
                                        </td>
                                        <td>
                                            <span class="font-weight-bold">Sex</span> <strong class="text-danger text-capitalize"><?= $patients_profile->sex;  ?></strong>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>



                        </div>
                        <div class="row">

                            <div class="col-lg-3">

                                <div class="ibox">
                                    <div class="ibox-content">
                                        <h3 class="font-weight-bold">About <?= $patients_profile->patient_name;  ?></h3>

                                        <p class="small">
                                            <?= $patients_profile->briefs;  ?>
                                            <br>
                                            <br>
                                            <a href="add_encounters.php?aset=<?= $get_asset_id; ?>"><button class="btn btn-primary font-weight-bold btn-outline">Add Encounter Note</button></a>
                                        </p>

<!--                                        <p class="small font-bold">-->
<!--                                            <span><i class="fa fa-circle text-navy"></i> Online status</span>-->
<!--                                        </p>-->

                                    </div>
                                </div>

                            </div>

                            <div class="col-lg-7">

                                <?php
                                $cc = $add_user->encounter_rs($get_asset_id,$hos_key);
                                foreach ($cc as $key=>$dd){
                                ?>
                                <div class="social-feed-box">

                                    <div class="float-right social-action dropdown">
                                        <button data-toggle="dropdown" class="dropdown-toggle btn-white">
                                        </button>
                                        <ul class="dropdown-menu m-t-xs">
                                            <li><a href="">Edit Note</a></li>
                                            <li><a href="">Delete Note</a></li>
                                        </ul>
                                    </div>
                                    <div class="social-avatar">
                                        <a href="" class="float-left">
                                            <img alt="image" src="usericon.png">
                                        </a>
                                        <div class="media-body">
                                            <a href="">
                                               <?= $dd->fullname;  ?>
                                            </a>
                                            <small class="text-muted">Posted on  <?= $dd->dated;  ?></small>
                                        </div>
                                    </div>
                                    <div class="social-body">
                                        <p style="color: #0f253c">
                                            <h2 class="font-weight-bold">Complaints</h2>
                                            <?= html_entity_decode($dd->compliant);  ?>
                                        </p>

                                        <p style="color: #0f253c">
                                        <h2 class="font-weight-bold">Examination</h2>
                                            <?= html_entity_decode($dd->exam);  ?>
                                        </p>

                                        <p style="color: #0f253c">
                                        <h2 class="font-weight-bold">Diagnosis</h2>
                                            <?= html_entity_decode($dd->diagonosis);  ?>
                                        </p>

                                        <div class="btn-group">

                                        </div>
                                    </div>
                                    <div class="social-footer">

                                        <?php
                                        $comment = $add_user->all_encounters($dd->id);
                                        foreach ($comment as $key=> $ads){
                                        ?>
                                        <div class="social-comment">
                                            <a href="" class="float-left">
                                                <img alt="image" src="usericon.png">
                                            </a>
                                            <div class="media-body">
                                                <a href="profile_2.html#">
                                                    <?= $ads->fullname;  ?>
                                                </a>
                                                <?= $ads->comment;  ?>
                                                <br>
                                                -
                                                <small class="text-muted"> <?= $ads->dated;  ?></small>
                                            </div>
                                        </div>
                                        <?php
                                        }
                                        ?>

                                        <div class="social-comment">
                                            <div class="media-body">
                                                <textarea class="form-control comments" placeholder="Write comment..." id=""></textarea><button class="btn btn-white btn-xs add_cc" id="" data-enid="<?= $dd->id;  ?>" data-doc="<?= $user_id;  ?>"> <i class="fa fa-comments pull-right"></i> Comment</button>

                                            </div>
                                        </div>

                                    </div>

                                </div>

                                <?php
                                }
                                ?>



                            </div>

                        </div>

                    </div>




                </div>
            </div>
        </div>
        <input type="hidden" value="<?= $hos_key; ?>" id="host_key">
        <?php
        include_once "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- iCheck -->
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script src="js/plugins/dataTables/datatables.min.js"></script>


<script>

    // Upgrade button class name
    $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

    $(document).ready(function(){
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [

            ]

        });

    });

</script>

<script>
    $(document).ready(function () {

        $(document).on('click', '.add_cc', function() {
            // get the para from data-
            const comments = $(".comments").val();
            const enid = $(this).attr("data-enid");
            const doc = $(this).attr("data-doc");

            if(comments=== 0){
                swal("Not allowed !", "Comments Needed!", "error");
            }else{
                $.ajax({
                    url: "ajax/add_encounter_comments.php",
                    method: "GET",
                    data: {
                        comments: comments,enid:enid
                    },
                    success: function (data) {

                        swal("Good job!", "Comments Added!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);

                        if (data.trim() == 'done') {

                        }
                    }
                });
            }

        });


        $("#add_lab_test").click(function () {
            // get the para from data-
            const testname = $("#testname").val();
            const dpt = $("#dpt").val();
            const restri = $("#restri").val();
            const amount = $("#amount").val();
            const container = $("#container").val();
            const sample = $("#sample").val();
            const tat = $("#tat").val();
            const host_key = $("#host_key").val();

            if(testname=== ''){
                swal("Empty fields!", "Try Again!", "error");
            }else{
                $.ajax({
                    url: "ajax/add_test_list.php",
                    method: "GET",
                    data: {
                        testname: testname,dpt:dpt,host_key:host_key,restri:restri,amount:amount,container:container,sample:sample,tat:tat
                    },
                    success: function (data) {
                        swal("Good job!", "Test Case Added!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);

                        if (data.trim() == 'done') {

                        }
                    }
                });
            }

        });


        $(".del_lab_dpt").click(function () {

            // get the para from data-
            const host_fib = $(this).attr("data-id");
            $.ajax({
                url: "ajax/d_lab_dpt.php",
                method: "GET",
                data: {
                    host_fib: host_fib,
                },
                success: function (data) {
                    swal("Good job!", "This Lab Department Has Been Removed", "success");
                    setTimeout(
                        function () {
                            location.reload();
                        }, 3000);

                    if (data.trim() == 'done') {

                    }
                }
            });
        });


        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
</script>
</body>

</html>


