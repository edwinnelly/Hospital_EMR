<?php
include_once "inc/session.php";
include_once "inc/controller.php";
include_once "inc/user_data.php";
include_once "inc/site_controller.php";
$add_user = new controller;
$get_asset_id = ($add_user->get_request('aset'));
$post_id = ($add_user->get_request('post_id'));
$info = ($add_user->get_request('info'));
$patients_profile = $add_user->edit_patients($hos_key,$get_asset_id);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Patient profile | Surgical note</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/plugins/summernote/summernote-bs4.css" rel="stylesheet">
    <style>
        body, h1, h2, h3, h4, h5, h6  {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>

<body>

<div id="wrapper">

    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>

        <div class="wrapper wrapper-content">
            <div class="row">
                <div class="col-lg-2">
                    <?php
                    include_once "inc/counter_menu.php";
                    ?>
                </div>
                <div class="col-lg-10 animated fadeInRight">
                    <div class="mail-box-header">

                        <h2>
                            <h2 class="font-weight-bold">Patient's  / Surgical note Folder</h2>
                            <a href="host_patients_folder?aset=<?= base64_encode($get_asset_id); ?>"> <button class="font-weight-bold btn btn-danger btn-outline btn-rounded pull-right">Back to Patient Folder</button></a>
                       <br>
                        </h2>
                        <div class="mail-tools tooltip-demo m-t-md">
                            <div class="btn-group float-right">

                            </div>

                        </div>
                    </div>


                    <div class="wrapper wrapper-content animated fadeInRight">


                        <div class="row m-b-lg m-t-lg">
                            <div class="col-md-6">

                                <div class="profile-image">
                                    <img src="img/log.png" class="rounded-circle circle-border m-b-md" alt="profile">
                                </div>
                                <div class="profile-info">
                                    <div>
                                        <h2 class="no-margins font-weight-bold" style="text-transform: capitalize">
                                            <?= $patients_profile->patient_name;  ?>
                                        </h2>
                                        <h4>Clinical Note / Records</h4>

                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">

                            <div class="col-11">
                                <div class="modal-header">
                                    <a href="surgical_note?aset=<?= $get_asset_id ?>"> <p class="modal-title font-weight-bold">Back to Surgical Note</p></a>
                                </div>
                                <div class="modal-body">
                                    <form method="POST" id="submitForm">
                                        <div class="form-group row">

                                            <div class="col-sm-12">

                                                <div class="form-group"><label class="font-weight-bold">Note Descriptions</label>

                                                    <textarea class="summernote input-block-level vv" id="notes" name="description" cols="10" rows="18">

                                                                <?php echo base64_decode(htmlspecialchars($info));  ?>

                                </textarea>

                                                </div>

                                                <input type="hidden" value="<?= $get_asset_id; ?>" name="pid">
                                                <input type="hidden" value="<?= $post_id; ?>" name="post_id">

                                            </div>
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="submit"
                                           class="font-weight-bold btn btn-primary btn-outline btn-rounded pull-right"
                                           value="Update Notes" id="reset-btn">
                                </div>
                            </div>

                            </form>

                        </div>

                    </div>




                </div>
            </div>
        </div>
        <input type="hidden" value="<?= $hos_key; ?>" id="host_key">
        <?php
        include_once "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- iCheck -->
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script src="js/plugins/dataTables/datatables.min.js"></script>

<!-- SUMMERNOTE -->
<script src="js/plugins/summernote/summernote-bs4.js"></script>

<!-- Select2 -->
<script src="js/plugins/select2/select2.full.min.js"></script>
<script src="https://cdn.lordicon.com/lusqsztk.js"></script>
<script>
    $(document).ready(function(){

        $('.summernote').summernote();
        // $('.summernote1').summernote();

        $('document').ready(function() {
            // $('#summernote').summernote({ height: 200 });
            // $('.note-codable').attr('name', 'body').html('{{old('body')}}');
        });

    });
</script>


<script>
    $(document).ready(function () {
        /* function to login user */
        $("#submitForm").on('submit',(function(e) {
            e.preventDefault();
            var btn = $("#reset-btn");
            btn.attr('disabled', true).html("<i class='fa fa-spin fa-spinner'></i> processing");
            var datas = new FormData(this);
            $.ajax({
                url: "ajax/edit_surgical_note",
                type: "POST",
                data: datas,
                contentType: false,
                cache: false,
                processData:false,
                success: (data)=> {
                    if(data.trim() == "done"){
                        swal("Good job!", "Surgical Note Updated!", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);
                    }else{
                    }
                },

            });
        }));

    });


</script>
</body>

</html>




