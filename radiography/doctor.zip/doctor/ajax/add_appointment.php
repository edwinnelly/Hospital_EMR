    <?php
    include_once '../inc/controller.php';
    include_once '../inc/user_data.php';
    $add_roles = new controller;

     $tittle = $add_roles->post_request('tittle');
    $description = $add_roles->post_request('description');
    $dated = $add_roles->post_request('dated');
    $pid = $add_roles->post_request('pid');

    if($tittle==''){

    }else{
        $new_class = $add_roles->add_appointment($hos_key,$user_id,$tittle,$description,$dated,$pid);
        if ($new_class == "success") {
            echo 'done';
        }
    }




