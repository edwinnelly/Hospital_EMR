    <?php
    include_once '../inc/controller.php';
    include_once '../inc/user_data.php';
    $add_roles = new controller;
    $ee = $add_roles->get_request('ee');
    $ee1 = $add_roles->get_request('ee1');
    $ss = json_encode($_GET['ss']);
    $pid = $add_roles->get_request('pid');

    $new_class = $add_roles->add_encounter($ee, $ee1, $ss, $pid, $user_id, $hos_key);
    if ($new_class == "success") {
        echo 'done';
    }