    <?php
    include_once '../inc/controller.php';
    include_once '../inc/user_data.php';
    $add_roles = new controller;

    $name_f = $add_roles->post_request('name_f');
    $i_amount = $add_roles->post_request('i_amount');
    $out_amount = $add_roles->post_request('out_amount');
    $comment = $add_roles->post_request('comment');
    $dated = $add_roles->post_request('dated');
    $pid = $add_roles->post_request('pid');

    if ($name_f == '') {

    } else {
        $new_class = $add_roles->add_fluids($hos_key, $user_id, $name_f, $i_amount,$out_amount,$comment, $dated, $pid);
        if ($new_class == "success") {
            echo 'done';
        }
    }




