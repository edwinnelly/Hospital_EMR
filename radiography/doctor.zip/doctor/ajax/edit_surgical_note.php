    <?php
    include_once '../inc/controller.php';
    include_once '../inc/user_data.php';
    $add_roles = new controller;
     $description = $add_roles->post_request('description');
     $pid = $add_roles->post_request('pid');
     $post_id = $add_roles->post_request('post_id');

    if($description==''){

    }else{
        $new_class = $add_roles->update_surgical_note($description,$pid,$post_id);
        if ($new_class == "success") {
            echo 'done';
        }
    }




