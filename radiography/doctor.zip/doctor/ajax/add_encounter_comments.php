    <?php
    include_once '../inc/controller.php';
    include_once '../inc/user_data.php';
    $add_roles = new controller;

    $comments = $add_roles->get_request('comments');
    $enid = $add_roles->get_request('enid');


    $new_class = $add_roles->add_ecounter_comment($comments, $enid, $user_id, $hos_key);
    if ($new_class == "success") {
        echo 'done';
    }