    <?php
    include_once '../inc/controller.php';
    include_once '../inc/user_data.php';
    $add_roles = new controller;

      $chart_id = $add_roles->get_request('chart_id');
       $delays = $add_roles->get_request('delays');

     $new_class = $add_roles->acn_chart($chart_id,$delays);
    if ($new_class == "success") {
        echo 'done';
    }