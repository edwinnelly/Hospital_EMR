    <?php
    include_once '../inc/controller.php';
    include_once '../inc/user_data.php';
    $add_roles = new controller;


    $description = $add_roles->post_request('description');
    $pid = $add_roles->post_request('pid');

    if($description==''){

    }else{
        $new_class = $add_roles->add_clci_notes($hos_key,$user_id,$description,$pid);
        if ($new_class == "success") {
            echo 'done';
        }
    }




