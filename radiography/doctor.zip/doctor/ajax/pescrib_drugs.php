    <?php
    include_once '../inc/controller.php';
    include_once '../inc/user_data.php';
    $add_roles = new controller;
    $dg = $add_roles->get_request('dg');
    $du = $add_roles->get_request('du');
    $fz = $add_roles->get_request('fz');
    $qty = $add_roles->get_request('qty');
    $pid = $add_roles->get_request('uid');

    //add key
     $keys = sha1(rand(1234, 123456));
    $uid = uniqid();
    $setup_time =24/$fz;
    $dose = $du*$fz-1;

    $now = new DateTime();
    $nowa=0;
    while ($nowa <= $dose) {
//        echo $rt = $now->format('h:i:s a');
        $result = $now->format('Y-m-d h:i:s a');
        $now->modify(+$setup_time .'hours');

        $new_class = $add_roles->chart_drugs($result,$dg,$pid,$keys,$uid,$fullname);
        $nowa++;
    }
    $new_class = $add_roles->pescribe_drugs($dg, $du, $fz, $qty, $hos_key,$pid,$keys,$user_id,$uid);
    if ($new_class == "success") {
        echo 'done';
    }