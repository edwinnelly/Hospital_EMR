    <?php
    include_once '../inc/controller.php';
    include_once '../inc/user_data.php';
    $add_roles = new controller;

    $weight = $add_roles->post_request('weight');
    $height = $add_roles->post_request('height');
    $bp = $add_roles->post_request('bp');
    $bt = $add_roles->post_request('bt');
    $heartr = $add_roles->post_request('heartr');
    $r_rate = $add_roles->post_request('r_rate');
    $oxygens = $add_roles->post_request('oxygens');
    $randombs = $add_roles->post_request('randombs');
    $abdominalg = $add_roles->post_request('abdominalg');
    $fasting_bs = $add_roles->post_request('fasting_bs');
    $h_circumference = $add_roles->post_request('h_circumference');
    $chest_c = $add_roles->post_request('chest_c');
    $mac = $add_roles->post_request('mac');
    $subscapular = $add_roles->post_request('subscapular');
    $triceps = $add_roles->post_request('triceps');
    $additional = $add_roles->post_request('additional');
    $patient_id = $add_roles->post_request('patient_id');

    $new_class = $add_roles->add_vitals($patient_id,$weight,$height,$bp,$bt,$hos_key,$user_id,$heartr,$r_rate,$oxygens,$randombs,$abdominalg,$fasting_bs,$h_circumference,$chest_c,$mac,$subscapular,$triceps,$additional);
    if ($new_class == "success") {
        echo 'done';
    }



