<?php
include_once "inc/session.php";
include_once "inc/controller.php";
include_once "inc/user_data.php";
include_once "inc/site_controller.php";
$add_user = new controller;
$ds_id = $add_user->get_request('aset');
$pid = base64_decode($add_user->get_request('fid'));
function time_elapsed_string($datetime, $full = false)
{
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ' : 'just now';
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Patient profile | drug administration</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <style>
        body, h1, h2, h3, h4, h5, h6 {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>
</head>

<body>

<div id="wrapper">

    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>

        <div class="wrapper wrapper-content">
            <div class="row">

                <div class="col-lg-10 animated fadeInRight">
                    <div class="mail-box-header">

                        <h2>
                            <h3 class="font-weight-bold"> Drug Chart</h3>
                        </h2>
                        <div class="mail-tools tooltip-demo m-t-md">
                            <a href="prescriptions?aset=<?= $ds_id;  ?>"> <button class="font-weight-bold btn btn-outline btn-primary btn-rounded">Medication List
                            </button></a>

                        </div>
                    </div>
                    <div class="mail-box">
                        <div class="ibox-content table-responsive">

                            <table class="table table-hover table-mail dataTables-example">
                                <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Drugs Name</th>
                                    <th>DateTime</th>
                                    <th>Given By</th>
                                    <th>Pending / Delays</th>
                                    <th>Status</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $cc = $add_user->ps_adminstrations($ds_id, $pid);
                                $i = 0;
                                foreach ($cc as $key => $values) {
                                    $i++;
                                    ?>
                                    <tr class="gradeA">
                                        <td><?= $i; ?></td>
                                        <td><?= $values->drugs_name; ?></td>
                                        <td><?= $values->date_time; ?></td>
                                        <td><?= $values->doc_name; ?></td>
                                        <td><?php $tn = ($values->date_time);
                                            $tv = date('Y-m-d h:i:s a');
                                            $time_to = strtotime($tn);
                                            $time_now = strtotime($tv);
                                            $time_diff = $time_now - $time_to;

                                            if ($time_to < $time_now) {
                                                if($values->delays==''){
                                                    echo $tn = time_elapsed_string($values->date_time);echo "Delay";
                                                }else{
                                                    echo $values->delays; echo '<span style="margin-left: 5px;">Ago</span>';
                                                }

                                            } else {
                                                echo $tn = time_elapsed_string($values->date_time);echo "Pending";
                                            }
                                             ?></td>
                                        <td>

                                            <?php
                                            $tn = ($values->date_time);
                                            $tv = date('Y-m-d h:i:s a');
                                            $time_to = strtotime($tn);
                                            $time_now = strtotime($tv);
                                            $time_diff = $time_now - $time_to;

                                            if ($time_to < $time_now) {
                                                if($values->status==1){
                                                    echo'<span class="fa fa-check text-success"></span>';
                                                }else{
                                                    echo '<button class="dispense btn btn-primary font-weight-bold btn-sm btn-rounded btn-outline" data-id="'.$values->id.'" data-delays="'.time_elapsed_string($values->date_time).'"  >
                                                dispense
                                            </button>';
                                                }

                                            } else {
                                                echo 'Not Yet Time';
                                            }

                                            ?>


                                        </td>

                                    </tr>
                                    <?php
                                }
                                ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        include_once "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- iCheck -->
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script src="js/plugins/dataTables/datatables.min.js"></script>


<script>

    // Upgrade button class name
    $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

    $(document).ready(function () {
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                // { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {
                    extend: 'print',
                    customize: function (win) {
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });

    });

</script>

<script>
    $(document).ready(function () {



        $(".dispense").click(function () {

            // get the para from data-
            const chart_id = $(this).attr("data-id");
            const delays = $(this).attr("data-delays");
            $.ajax({
                url: "ajax/drugs_taken.php",
                method: "GET",
                data: {
                    chart_id: chart_id,delays:delays
                },
                success: function (data) {
                    swal("Good job!", "Charted", "success");
                    setTimeout(
                        function () {
                            location.reload();
                        }, 3000);

                    if (data.trim() == 'done') {

                    }
                }
            });
        });


        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
</script>
</body>

</html>



