<?php
include "inc/site_controller.php";
 $get_asset_id = $add_user->get_request('aset');
$aptients_edit= $add_user->edit_patients($hos_key,$get_asset_id);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Encounter Profile | data</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">
    <link href="css/plugins/summernote/summernote-bs4.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300&display=swap" rel="stylesheet">
    <link href="css/plugins/select2/select2-bootstrap4.min.css" rel="stylesheet">
    <link href="css/plugins/select2/select2.min.css" rel="stylesheet">

    <style>
        body, h1, h2, h3, h4, h5, h6  {
            font-family: "Segoe UI", Arial, sans-serif;
        }
    </style>

</head>
<body>

<div id="wrapper">

    <?php
    include "inc/sidebar.php";
    ?>
    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <?php
            include "inc/header.php";
            ?>
        </div>
        <div class="col-lg-10">
            <h2 class="font-weight-bold"><img src="https://img.icons8.com/bubbles/452/sneezing-in-a-tissue.png" height="50"> Medical Encounter Note</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="">Home</a>
                </li>
                <li class="breadcrumb-item">
                    <a>App Views</a>
                </li>
                <li class="breadcrumb-item active">
                    <a href="host_patients.php"><button class="btn btn-primary btn-rounded btn-outline font-weight-bold">Patients List</button></a>

                </li>
            </ol>
        </div>


        <div class="wrapper wrapper-content animated fadeInDown">
            <div class="row">
                <div class="col-lg-10">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5 class="font-weight-bold"> History</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">


                            <div class="form-group">

                                <div class="col-lg-12">
                                    <div class="ibox ">


                                        <div class="ibox-content no-padding">

                                                <textarea class="summernote input-block-level" id="content" name="content" rows="18">

...
                                                    ...

                                                </textarea>

                                        </div>

                                    </div>
                                </div>
                            </div>



                            <br>
                            <br>
                        </div>
                    </div>


                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5 class="font-weight-bold"> Examination</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>


                            </div>
                        </div>
                        <div class="ibox-content">


                            <div class="form-group">

                                <div class="col-lg-12">
                                    <div class="ibox ">

                                        <div class="ibox-content no-padding">

                                                <textarea class="summernote input-block-level" id="content1" name="content" rows="18">

...
                                                    ...
                                                    ...

                                                </textarea>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <input type="hidden" value="<?= $get_asset_id;  ?>" id="pid">
                            <br>
                            <br>
                        </div>
                    </div>


                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5 class="font-weight-bold"> Diagnosis</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>


                            </div>
                        </div>
                        <div class="ibox-content">


                            <div class="form-group">

                                <div class="col-lg-12">
                                    <div class="ibox ">

                                        <div class="ibox-content no-padding">
                                            <form id="basic-form" method="post" action="">
                                            <div class="col-md-4">
<!--                                                <p>-->
<!--                                                    Select2 also supports multi-value select boxes. The select below is declared with the multiple attribute.-->
<!--                                                </p>-->
                                                <select placeholder="Choose options" class="select2_demo_2 form-control" multiple="multiple" name="cc[]">
                                                    <option value="">Choose Case</option>
                                                    <?php
                                                $case_files = $add_user->case_files($hos_key);
                                                foreach ($case_files as $key=>$vv){
                                                ?>
                                                    <option value="<?= $vv->case_name; ?>"><?= $vv->case_name; ?></option>
                                                    <?php
                                                }
                                                    ?>
                                                </select>

                                            </div>
                                            <input type="submit" name="bn" class="btn btn-primary btn-rounded font-weight-bold" value="Add Diagnosis">
                                        </div>
                                    </form>
                                        <?php
                                        //declare all vars
                                        @$bn = $add_user->post_request('bn');
                                        @$cc = $_POST['cc'];
                                        if($bn){
                                            foreach (@$cc as $key =>$cases){
                                                $add_user->add_dia_case($cases,$get_asset_id);
                                            }
                                            echo '<script>alert("Diagnosis Case Added!")</script>';
                                        }

                                        ?>
                                        <input type="hidden" id="pid" value="<?= $get_asset_id; ?>">
                                        <br>
                                        <div>

                                            <button class="btn btn-primary btn-rounded btn-outline float-right m-t-n-xs"
                                                    type="submit" id="add_cc_users"><strong>Add Encounter Note</strong></button>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>


                    </div>
                </div>
            </div>
        </div>
        <?php
        include "inc/footer.php";
        ?>
    </div>
</div>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<script src="js/plugins/dataTables/datatables.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/js_hospital.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>

<!-- SUMMERNOTE -->
<script src="js/plugins/summernote/summernote-bs4.js"></script>

<!-- Select2 -->
<script src="js/plugins/select2/select2.full.min.js"></script>

<script>
    $(document).ready(function(){

        $('.summernote').summernote();
       // $('.summernote1').summernote();

    });
</script>

<!-- Page-Level Scripts -->
<script>

    // Upgrade button class name
    $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

    $(document).ready(function () {

        $("#add_cc_users").click(function () {
            // get the para from data-
            const ee = $('#content').val();
            const ee1 = $('#content1').val();
            const ss = $('.select2_demo_2').val();
            const pid = $('#pid').val();

            if(pid===''){
                swal("Not Ok!", "Select A Patient", "error");
            }else {
                $.ajax({
                    url: "ajax/add_encounter.php",
                    method: "GET",
                    data: {
                        ee: ee, ee1: ee1, ss: ss, pid: pid
                    },
                    success: function (data) {
                        swal("Good job!", "New Encounter Note Added", "success");
                        setTimeout(
                            function () {
                                location.reload();
                            }, 3000);

                        if (data.trim() == 'done') {

                        }
                    }
                });
            }


        });


        $("#clr").click(function () {
            // get the para from data-
            const ee = document.getElementById('content').value = '';
            const ee1 = $('#content1').val("");
            const ss = $('.select2_demo_2').val();
            const pid = $('#pid').val();
        });

    });

</script>
<script src="js/plugins/iCheck/icheck.min.js"></script>
<script>
    $(document).ready(function () {
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
</script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>



<!-- Initialize Quill editor -->
<script>
    $(".select2_demo_2").select2({
        theme: 'bootstrap4',
    });
</script>

</body>

</html>

