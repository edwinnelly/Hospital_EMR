
        <label>Cheque Number</label>
        <input type="number" maxlength="30" placeholder="Payment Number" required class="form-control" id="chqe" name="chqe">