<?php
error_reporting(0);
ini_set('display_errors', 0);
// date_default_timezone_set("Africa/Lagos");
// /** Database connection credentials for localhost **/
//      define("host", "localhost");
//      define("user", "daroffle_updated");
//      define("password", "Edwin3l3@E");
//      define("database", "daroffle_updated");
//      define("apikey", "");
?>



<?php
/** Database connection credentials for localhost **/
define("host", "localhost");
define("user", "root");
define("password", "");
define("database", "app_data");
define("apikey", "");




?>



